document.getElementById('close').addEventListener('click',()=>{
    document.getElementById('cookie').style.display="none"
      });
    