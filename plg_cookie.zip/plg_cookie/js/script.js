document.getElementById('accept').addEventListener('click',()=>{
    document.getElementById('cookie').style.display="none";
});

  document.getElementById('close').addEventListener('click',()=>{
      document.getElementById('cookie').style.display="none";
});
